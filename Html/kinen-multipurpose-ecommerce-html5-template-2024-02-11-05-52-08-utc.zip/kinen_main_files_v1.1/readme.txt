Kinen is a Multipurpose Ecommerce Template designed for All kinds of Shop And Business. It's an HTML5 template based on latest Bootstrap v4.x It includes. Anyone can easily update/edit this template by following our Well Sorted Documentation.


==========================================================================================================
WHMCS Template included in "whmcs-template" (folder) with installation instruction "readme.txt"
==========================================================================================================

==========================================================================
Well Sorted Documentation included in "documentation" (folder).
==========================================================================

==========================================================================
Changelog included in "documentation/changelog" (folder).
==========================================================================


SOURCE AND CREADITS:
====================

Photos:

    All 'images' used on the demo site is for demonstration purposes only and are not included in the main download file.

Fonts Used:

    Google Fonts (Poppins and Karla) - https://fonts.google.com
    Font Awesome - https://github.com/FortAwesome/Font-Awesome/

Frameworks / Libraries:

    jQuery - http://jquery.com
    Twitter Bootstrap - http://getbootstrap.com

Plugins Used:

    RetinaJS - https://github.com/imulus/retinajs
    Magnific popup - https://github.com/dimsemenov/Magnific-Popup
    Swiper slider - https://github.com/nolimits4web/swiper
    Parsley JS - https://github.com/guillaumepotier/Parsley.js
    Waypoints - https://github.com/imakewebthings/waypoints